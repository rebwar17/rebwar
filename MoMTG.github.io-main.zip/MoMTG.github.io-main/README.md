# MoMTG.github.io
a {
	color: rgb(5, 79, 114);
   }
p {
    color: rgb(0, 17, 252);
    text-align: center;
  }

li {
  display: block;
  color: aqua;
  text-align: left;
  padding: 10px;
  text-decoration: none;
  font-size: large;
}

h3 {
    color: rgb(43, 20, 128);
    text-align: left;
}
body {
  background-color: white;
}

ul { 
  list-style-type: none;
  margin: 0%;
  padding: 0;
  overflow: hidden;
  text-decoration: none;
}

li a:hover {
  background-color: aqua;
}

h1 { 
  text-align: left;
  color: red;
}